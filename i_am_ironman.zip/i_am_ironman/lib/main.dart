import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        body: Center(
          child: Image(
            image: NetworkImage(
                'https://img.indiefolio.com/fit-in/1100x0/filters:format(webp):fill(transparent)/project/body/ee7ded858e9648e36450501cfbcae610.jpg'),
          ),
        ),
        backgroundColor: Colors.amber,
        appBar: AppBar(
          backgroundColor: Colors.red[700],
          title: Center(
            child: Text('I am Ironman'),
          ),
        ),
      ),
    ),
  );
}
