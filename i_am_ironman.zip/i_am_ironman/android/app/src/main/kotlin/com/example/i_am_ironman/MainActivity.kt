package com.example.i_am_ironman

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
