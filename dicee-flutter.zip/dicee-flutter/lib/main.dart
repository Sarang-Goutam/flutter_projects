import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  return runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.red,
        appBar: AppBar(
          title: Text('Dicee'),
          backgroundColor: Colors.red,
        ),
        body: DiceNumber(),
      ),
    ),
  );
}

class DiceNumber extends StatefulWidget {
  const DiceNumber({Key key}) : super(key: key);
  @override
  State<DiceNumber> createState() => _DiceNumberState();
}

class _DiceNumberState extends State<DiceNumber> {
  int leftDiceNumber = 1;
  int rightDiceNumber = 1;
  void Imagepressed() {
    leftDiceNumber = Random().nextInt(6) + 1;
    rightDiceNumber = Random().nextInt(6) + 1;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              child: FlatButton(
                onPressed: () {
                  setState(() {
                    Imagepressed();
                  });
                },
                child: Image.asset('images/dice$leftDiceNumber.png'),
              ),
            ),
          ),
          Expanded(
            child: Container(
              child: FlatButton(
                onPressed: () {
                  setState(() {
                    Imagepressed();
                  });
                },
                child: Image.asset('images/dice$rightDiceNumber.png'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
